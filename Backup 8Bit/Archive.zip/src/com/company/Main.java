package com.company;

public class Main {
    public static void main(String[] args) {
        new CompressedFile("text.txt");
        System.out.println("Compressed");
        new DecompressedFile("text.tin");
    }
}
